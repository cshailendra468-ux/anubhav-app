package com.anubhav.writer

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("anubhav", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,28,28,20) }
        val title = TextView(this).apply { text="अनुभव"; textSize=32f; setTextColor(Color.rgb(70,35,110)); setPadding(0,0,0,8) }
        val sub = TextView(this).apply { text="आपकी रचनाओं की अपनी जगह"; textSize=16f; setPadding(0,0,0,22) }
        root.addView(title); root.addView(sub)
        val newBtn = Button(this).apply { text="✍  नई रचना लिखें"; setOnClickListener { editor(null) } }
        root.addView(newBtn)
        val scroll=ScrollView(this); list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        val keys=prefs.all.keys.filter{it.startsWith("title_")}.sortedDescending()
        if(keys.isEmpty()) { list.addView(TextView(this).apply{text="\nअभी कोई रचना नहीं है।\nऊपर से “नई रचना लिखें” दबाएँ।";textSize=17f}) }
        for(k in keys) {
            val id=k.removePrefix("title_"); val card=Button(this).apply{
                text=prefs.getString(k,"बिना शीर्षक")+"\n"+prefs.getString("date_"+id,"")
                textSize=17f; setOnClickListener{editor(id)}
            }; list.addView(card, LinearLayout.LayoutParams(-1, -2).apply{setMargins(0,8,0,8)})
        }
    }

    private fun editor(id:String?) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,10)}
        val title=EditText(this).apply{hint="रचना का शीर्षक";textSize=22f}
        val body=EditText(this).apply{hint="यहाँ अपनी रचना लिखें...";gravity=Gravity.TOP;textSize=18f;minLines=12}
        val save=Button(this).apply{text="💾  सुरक्षित करें"}
        val share=Button(this).apply{text="📤  शेयर करें"}
        val back=Button(this).apply{text="←  वापस"}
        if(id!=null){title.setText(prefs.getString("title_"+id,""));body.setText(prefs.getString("body_"+id,""))}
        box.addView(back);box.addView(title);box.addView(body,LinearLayout.LayoutParams(-1,0,1f));box.addView(save);box.addView(share)
        setContentView(box)
        back.setOnClickListener{showHome()}
        save.setOnClickListener{
            val rid=id ?: System.currentTimeMillis().toString()
            prefs.edit().putString("title_"+rid,title.text.toString().ifBlank{"बिना शीर्षक"})
                .putString("body_"+rid,body.text.toString())
                .putString("date_"+rid,SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.getDefault()).format(Date())).apply()
            Toast.makeText(this,"रचना सुरक्षित हो गई",Toast.LENGTH_SHORT).show()
            showHome()
        }
        share.setOnClickListener{
            val s=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,title.text.toString()+"\n\n"+body.text.toString())}
            startActivity(Intent.createChooser(s,"रचना शेयर करें"))
        }
    }
}
